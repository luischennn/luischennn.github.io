---
title: Events
---

## Client events

### ox:playerLoaded

Triggered once the player has selected a character and spawned.

```lua
AddEventHandler('ox:playerLoaded', function(data) end)
```

### ox:playerLogout

Triggered when the player enters character selection if they were previously playing a character.

```lua
AddEventHandler('ox:playerLogout', function() end)
```

### ox:statusTick

Triggered every 1000ms interval, when status values are updated internally.

```lua
AddEventHandler('ox:statusTick', function(statuses) end)
```

## Networked events

### ox:setGroup

Triggered when the player's grade in a group is modified on the server with `player.setGroup`.

```lua
RegisterNetEvent('ox:setGroup', function(group, grade) end)
```

### ox:licenseAdded

Triggered when the player has been granted a license.

```lua
RegisterNetEvent('ox:licenseAdded', function(name) end)
```

### ox:licenseRemoved

Triggered when the player's license is revoked.

```lua
RegisterNetEvent('ox:licenseRemoved', function(name) end)
```
